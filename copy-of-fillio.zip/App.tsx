
import React, { useState } from 'react';
import { DocumentType, PFSData, AppState } from './types';
import { DOC_OPTIONS, PFS_STEPS } from './constants';
import Layout from './components/Layout';
import StepFlow from './components/StepFlow';
import Summary from './components/Summary';
import LandingPage from './components/LandingPage';
import AuthModal from './components/AuthModal';
import Paywall from './components/Paywall';

const INITIAL_PFS_DATA: PFSData = {
  fullName: '',
  asOfDate: new Date().toISOString().split('T')[0],
  cashAssets: [],
  realEstateAssets: [],
  investmentAssets: [],
  realEstateLiabilities: [],
  otherLiabilities: []
};

const DocumentPreviewSkeleton: React.FC<{ type: DocumentType }> = ({ type }) => {
  switch (type) {
    case DocumentType.PFS:
      return (
        <div className="flex gap-4 w-full h-full p-6 bg-white">
          <div className="flex-1 flex flex-col gap-4">
            <div className="h-4 w-3/4 bg-blue-100 rounded-md"></div>
            {[...Array(4)].map((_, i) => <div key={i} className="h-2.5 w-full bg-slate-50 rounded-md"></div>)}
          </div>
          <div className="flex-1 flex flex-col gap-4">
            <div className="h-4 w-3/4 bg-indigo-100 rounded-md"></div>
            {[...Array(3)].map((_, i) => <div key={i} className="h-2.5 w-full bg-slate-50 rounded-md"></div>)}
          </div>
        </div>
      );
    case DocumentType.DEBT_SCHEDULE:
      return (
        <div className="w-full h-full p-6 flex flex-col gap-5 bg-white">
          <div className="flex gap-2 border-b-2 border-slate-50 pb-4">
             <div className="w-1/3 h-3 bg-slate-200 rounded"></div>
             <div className="w-1/3 h-3 bg-slate-200 rounded"></div>
             <div className="w-1/3 h-3 bg-slate-200 rounded"></div>
          </div>
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex gap-2 border-b border-slate-50 pb-3">
              <div className="w-1/3 h-2.5 bg-slate-100 rounded"></div>
              <div className="w-1/3 h-2.5 bg-slate-100 rounded"></div>
              <div className="w-1/3 h-2.5 bg-blue-100 rounded"></div>
            </div>
          ))}
        </div>
      );
    case DocumentType.INCOME_STATEMENT:
      return (
        <div className="w-full h-full p-6 flex flex-col gap-6 bg-white">
          <div className="space-y-3">
            <div className="h-4 w-1/4 bg-slate-200 rounded"></div>
            <div className="h-10 w-full bg-blue-50/50 rounded-md border border-blue-100/30"></div>
          </div>
          <div className="space-y-3">
            <div className="h-4 w-1/4 bg-slate-100 rounded"></div>
            <div className="h-20 w-full bg-slate-50 rounded-md"></div>
          </div>
          <div className="mt-auto h-6 w-1/2 bg-blue-600/10 rounded-md self-end"></div>
        </div>
      );
    case DocumentType.BALANCE_SHEET:
      return (
        <div className="w-full h-full p-6 flex flex-col gap-3 bg-white">
          <div className="flex-[1.2] bg-slate-50 rounded-lg flex flex-col p-4 gap-3 border border-slate-100">
            <div className="h-3 w-1/3 bg-blue-100 rounded"></div>
            <div className="h-2.5 w-full bg-slate-200/40 rounded"></div>
          </div>
          <div className="flex-1 bg-slate-50 rounded-lg flex flex-col p-4 gap-3 border border-slate-100">
            <div className="h-3 w-1/3 bg-indigo-100 rounded"></div>
            <div className="h-2.5 w-full bg-slate-200/40 rounded"></div>
          </div>
          <div className="flex-1 bg-blue-50/50 rounded-lg flex flex-col p-4 gap-3 border border-blue-100/20">
            <div className="h-3 w-1/3 bg-blue-200/50 rounded"></div>
          </div>
        </div>
      );
    default:
      return null;
  }
};

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isPro, setIsPro] = useState(false);
  const [hasPaidForDoc, setHasPaidForDoc] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup' | null>(null);
  const [view, setView] = useState<'landing' | 'flow' | 'review' | 'paywall'>('landing');
  const [search, setSearch] = useState('');
  const [state, setState] = useState<AppState>({
    selectedDoc: null,
    currentStep: 0,
    data: INITIAL_PFS_DATA
  });

  const handleLogin = () => {
    setIsLoggedIn(true);
    setAuthMode(null);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsPro(false);
    setHasPaidForDoc(false);
    setView('landing');
  };

  const selectDocument = (type: DocumentType) => {
    setState(prev => ({ ...prev, selectedDoc: type, currentStep: 0 }));
    setView('flow');
  };

  const handleNext = () => {
    if (state.currentStep < PFS_STEPS.length - 1) {
      setState(prev => ({ ...prev, currentStep: prev.currentStep + 1 }));
    } else {
      setView('review');
    }
  };

  const handleBack = () => {
    if (state.currentStep > 0) {
      setState(prev => ({ ...prev, currentStep: prev.currentStep - 1 }));
    } else {
      setView('landing');
    }
  };

  const updateData = (newData: Partial<PFSData>) => {
    setState(prev => ({
      ...prev,
      data: { ...prev.data, ...newData }
    }));
  };

  const handleExportRequested = () => {
    if (isPro || hasPaidForDoc) return;
    setView('paywall');
  };

  const handlePaymentSuccess = (type: 'one-time' | 'subscription') => {
    if (type === 'subscription') setIsPro(true);
    else setHasPaidForDoc(true);
    setView('review');
    if (!isLoggedIn) setAuthMode('signup');
  };

  if (!isLoggedIn && view === 'landing') {
    return (
      <div className="relative">
        <LandingPage 
          onGetStarted={() => setAuthMode('signup')} 
          onSignIn={() => setAuthMode('signin')}
          onDocClick={selectDocument}
        />
        {authMode && (
          <AuthModal 
            mode={authMode} 
            onClose={() => setAuthMode(null)} 
            onSuccess={handleLogin}
            setMode={setAuthMode}
          />
        )}
      </div>
    );
  }

  return (
    <Layout 
      currentView={view} 
      onHomeClick={() => setView('landing')}
      onLogout={handleLogout}
    >
      <div className="fade-in h-full bg-[#F8FAFC]">
        {view === 'landing' && (
          <div className="flex h-full">
            <div className="flex-grow overflow-y-auto px-6 md:px-12 lg:px-20 py-16 lg:py-24">
              <div className="max-w-6xl mx-auto">
                <div className="mb-20 text-left max-w-3xl">
                  <div className="inline-flex items-center gap-2 bg-[#0070e0]/10 text-[#0070e0] px-4 py-2 rounded-full text-[11px] font-black uppercase tracking-widest mb-6">
                    <span className="iconify text-lg" data-icon="solar:verified-check-bold-duotone"></span>
                    {isLoggedIn ? 'Workspace Active' : 'Start Designing'}
                  </div>
                  <h1 className="text-5xl md:text-7xl font-[900] text-slate-900 mb-6 tracking-[-0.04em] leading-[0.95]">
                    {isLoggedIn ? 'Select a document' : 'Create your'} <br/>
                    <span className="text-[#0070e0]">{isLoggedIn ? 'template.' : 'financial doc.'}</span>
                  </h1>
                  
                  <div className="relative group max-w-2xl mt-12">
                    <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none transition-colors group-focus-within:text-[#0070e0]">
                      <span className="iconify text-slate-300 text-2xl" data-icon="solar:magnifer-linear"></span>
                    </div>
                    <input 
                      type="text" 
                      placeholder="Search documents..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="w-full bg-white border-none rounded-[1.5rem] py-6 pl-16 pr-8 text-lg focus:ring-[12px] focus:ring-[#0070e0]/10 outline-none transition-all placeholder:text-slate-300 font-semibold shadow-[0_20px_50px_-12px_rgba(0,0,0,0.08)]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 lg:gap-14">
                  {DOC_OPTIONS.filter(doc => 
                    doc.title.toLowerCase().includes(search.toLowerCase()) ||
                    doc.outcomeDescription.toLowerCase().includes(search.toLowerCase())
                  ).map((doc) => (
                    <div 
                      key={doc.type} 
                      onClick={() => selectDocument(doc.type)}
                      className={`group relative flex flex-col bg-white border-2 cursor-pointer ${doc.isPopular ? 'border-[#0070e0]/10 ring-8 ring-[#0070e0]/5' : 'border-transparent'} rounded-[3rem] overflow-hidden transition-all duration-500 hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.12)] hover:-translate-y-3`}
                    >
                      <div className="h-72 bg-slate-50/80 flex items-center justify-center relative overflow-hidden group-hover:bg-[#0070e0]/5 transition-colors duration-500">
                        <div className="w-[220px] h-[280px] bg-white rounded-xl shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] border border-slate-200 transform -rotate-1 group-hover:rotate-1 group-hover:scale-105 transition-all duration-700 ease-out z-10 overflow-hidden">
                           <DocumentPreviewSkeleton type={doc.type} />
                        </div>
                      </div>
                      <div className="p-10 flex flex-col flex-grow bg-white">
                        <h3 className="text-2xl font-[900] text-[#002169] tracking-tight leading-none mb-4">{doc.title}</h3>
                        <p className="text-slate-500 text-sm font-medium leading-relaxed mb-6 flex-grow">{doc.outcomeDescription}</p>
                        <div className="flex items-center justify-between text-[#0070e0] font-bold text-xs uppercase tracking-widest">
                           <span>{doc.timeEstimate} completion</span>
                           <span className="iconify text-xl transition-transform group-hover:translate-x-1" data-icon="solar:alt-arrow-right-bold-duotone"></span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'flow' && (
          <div className="h-full bg-white">
            <StepFlow state={state} onNext={handleNext} onBack={handleBack} onUpdate={updateData} />
          </div>
        )}

        {view === 'review' && (
          <div className="h-full bg-[#F8FAFC]">
            <Summary
              data={state.data}
              isLocked={!isPro && !hasPaidForDoc}
              onExportRequested={handleExportRequested}
              onEdit={() => setView('flow')}
              onReset={() => {
                setState(prev => ({ ...prev, data: INITIAL_PFS_DATA, currentStep: 0 }));
                setHasPaidForDoc(false);
                setView('landing');
              }}
            />
          </div>
        )}

        {view === 'paywall' && (
          <div className="h-full bg-[#F8FAFC]">
            <Paywall data={state.data} onBack={() => setView('review')} onSuccess={handlePaymentSuccess} onSignup={() => setAuthMode('signup')} />
          </div>
        )}
      </div>

      {authMode && (
        <AuthModal mode={authMode} onClose={() => setAuthMode(null)} onSuccess={handleLogin} setMode={setAuthMode} />
      )}
    </Layout>
  );
};

export default App;
