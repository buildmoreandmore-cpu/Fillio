
import React from 'react';
import { PFSData, FinancialItem } from '../types';

interface PDFPreviewProps {
  data: PFSData;
  totalAssets: number;
  totalLiabilities: number;
  netWorth: number;
}

const PDFPreview: React.FC<PDFPreviewProps> = ({ data, totalAssets, totalLiabilities, netWorth }) => {
  const formatCurrency = (val: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  const Section = ({ title, items }: { title: string, items: FinancialItem[] }) => (
    <div className="mb-6">
      <div className="flex justify-between border-b-2 border-slate-200 pb-1 mb-2">
        <h3 className="text-[10px] font-bold uppercase text-[#002169] tracking-wider">{title}</h3>
      </div>
      {items.length === 0 ? <p className="text-[9px] text-slate-400 italic">None reported.</p> : (
        <div className="space-y-1">
          {items.map((item) => (
            <div key={item.id} className="flex justify-between text-[10px]">
              <span className="text-slate-700">{item.description || 'Untitled'}</span>
              <span className="text-[#002169] font-bold">{formatCurrency(item.value)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="bg-white p-12 text-slate-900 min-h-[1056px] w-[816px] flex flex-col font-sans border border-slate-100">
      <div className="flex justify-between items-start border-b-4 border-[#002169] pb-8 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-[#002169] mb-1 uppercase tracking-tight">Personal Financial Statement</h1>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[9px]">Confidential Report</p>
        </div>
        <div className="text-right">
          <p className="text-base font-bold text-[#002169] uppercase">{data.fullName || 'NOT SPECIFIED'}</p>
          <p className="text-slate-500 text-[10px]">As of {new Date(data.asOfDate).toLocaleDateString()}</p>
        </div>
      </div>

      <div className="flex-grow grid grid-cols-2 gap-12">
        <div>
          <h2 className="text-[10px] font-bold bg-[#002169] text-white px-2 py-1 inline-block uppercase mb-6">Assets</h2>
          <Section title="Cash & Liquid" items={data.cashAssets} />
          <Section title="Investments" items={data.investmentAssets} />
          <Section title="Real Estate" items={data.realEstateAssets} />
          <div className="mt-8 pt-4 border-t-2 border-[#002169] flex justify-between">
            <span className="text-[10px] font-bold uppercase">Total Assets</span>
            <span className="text-sm font-bold text-[#002169]">{formatCurrency(totalAssets)}</span>
          </div>
        </div>
        <div>
          <h2 className="text-[10px] font-bold bg-[#002169] text-white px-2 py-1 inline-block uppercase mb-6">Liabilities</h2>
          <Section title="Mortgages" items={data.realEstateLiabilities} />
          <Section title="Other Debts" items={data.otherLiabilities} />
          <div className="mt-8 pt-4 border-t-2 border-[#002169] flex justify-between">
            <span className="text-[10px] font-bold uppercase">Total Liabilities</span>
            <span className="text-sm font-bold text-[#002169]">{formatCurrency(totalLiabilities)}</span>
          </div>
          <div className="mt-12 bg-slate-50 p-6 rounded-lg border border-slate-200">
            <div className="flex justify-between items-center border-t border-slate-200 pt-2 mt-2">
              <span className="text-xs font-bold uppercase text-[#002169]">Calculated Net Worth</span>
              <span className="text-xl font-bold text-[#0070e0]">{formatCurrency(netWorth)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-auto pt-8 flex justify-between text-[8px] text-slate-400 font-bold border-t border-slate-100">
        <p>Verified through Fillio. Page 1 of 1</p>
        <p>© 2024 Fillio Document Services</p>
      </div>
    </div>
  );
};

export default PDFPreview;
