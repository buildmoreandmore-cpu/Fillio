
import React, { useEffect } from 'react';
import { AppState, PFSData, FinancialItem } from '../types';
import { PFS_STEPS } from '../constants';

interface StepFlowProps {
  state: AppState;
  onNext: () => void;
  onBack: () => void;
  onUpdate: (data: Partial<PFSData>) => void;
}

const StepFlow: React.FC<StepFlowProps> = ({ state, onNext, onBack, onUpdate }) => {
  const currentStepDef = PFS_STEPS[state.currentStep];
  const progress = ((state.currentStep + 1) / PFS_STEPS.length) * 100;

  useEffect(() => {
    const listFields: (keyof PFSData)[] = [
      'cashAssets', 'investmentAssets', 'realEstateAssets', 
      'realEstateLiabilities', 'otherLiabilities'
    ];
    let updated = false;
    const newData: Partial<PFSData> = {};
    listFields.forEach(field => {
      const list = state.data[field];
      if (Array.isArray(list)) {
        if (list.length === 0 || (list[list.length - 1].description !== '' || list[list.length - 1].value !== 0)) {
          newData[field] = [...list, { id: Math.random().toString(36).substr(2, 9), description: '', value: 0 }] as any;
          updated = true;
        }
      }
    });
    if (updated) onUpdate(newData);
  }, [state.data, onUpdate]);

  const handleUpdateItem = (field: keyof PFSData, id: string, updates: Partial<FinancialItem>) => {
    const currentList = state.data[field] as FinancialItem[];
    const newList = currentList.map(item => item.id === id ? { ...item, ...updates } : item);
    onUpdate({ [field]: newList });
  };

  const handleRemoveItem = (field: keyof PFSData, id: string) => {
    const currentList = state.data[field] as FinancialItem[];
    if (currentList.length <= 1) return;
    onUpdate({ [field]: currentList.filter(item => item.id !== id) });
  };

  const renderFinancialList = (field: keyof PFSData, label: string) => {
    const list = (state.data[field] as FinancialItem[]) || [];
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <h4 className="text-xs font-bold text-[#002169] uppercase tracking-widest">{label}</h4>
          <span className="text-[10px] font-bold text-[#0070e0] flex items-center gap-1">
             <span className="iconify" data-icon="solar:shield-check-bold-duotone"></span> Encrypted
          </span>
        </div>
        <div className="space-y-2">
          {list.map((item, index) => (
            <div key={item.id} className="flex gap-4 items-center group">
              <input
                type="text"
                placeholder="Description"
                value={item.description}
                onChange={(e) => handleUpdateItem(field, item.id, { description: e.target.value })}
                className="flex-grow bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 outline-none focus:border-[#0070e0] transition-all text-sm font-semibold"
              />
              <div className="w-32 relative">
                <span className="absolute left-3 top-3 text-slate-400 font-bold text-sm">$</span>
                <input
                  type="number"
                  placeholder="0.00"
                  value={item.value || ''}
                  onChange={(e) => handleUpdateItem(field, item.id, { value: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-6 pr-4 py-3 outline-none focus:border-[#0070e0] transition-all text-sm font-bold text-right"
                />
              </div>
              {(!item.description && !item.value) ? <div className="w-10"></div> : (
                <button onClick={() => handleRemoveItem(field, item.id)} className="w-10 text-slate-300 hover:text-red-500 transition-colors">
                  <span className="iconify text-xl" data-icon="solar:trash-bin-trash-bold-duotone"></span>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-3xl mx-auto py-16 px-6 fade-in">
      <div className="mb-12">
        <div className="flex justify-between items-center mb-2">
           <h2 className="text-2xl font-bold text-[#002169]">{currentStepDef.title}</h2>
           <span className="text-xs font-bold text-[#0070e0]">{Math.round(progress)}%</span>
        </div>
        <div className="h-1 w-full bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-[#0070e0] transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-xl shadow-slate-200/20 mb-12">
        {state.currentStep === 0 && (
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Legal Full Name</label>
              <input
                type="text"
                value={state.data.fullName}
                onChange={(e) => onUpdate({ fullName: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-4 outline-none focus:border-[#0070e0] text-lg font-bold text-[#002169]"
                placeholder="Enter your name"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Statement Date</label>
              <input
                type="date"
                value={state.data.asOfDate}
                onChange={(e) => onUpdate({ asOfDate: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-4 outline-none focus:border-[#0070e0] text-lg font-bold text-[#002169]"
              />
            </div>
          </div>
        )}

        {state.currentStep === 1 && renderFinancialList('cashAssets', 'Cash Assets')}
        {state.currentStep === 2 && renderFinancialList('investmentAssets', 'Investments')}
        {state.currentStep === 3 && renderFinancialList('realEstateAssets', 'Real Estate')}
        {state.currentStep === 4 && renderFinancialList('realEstateLiabilities', 'Mortgages')}
        {state.currentStep === 5 && renderFinancialList('otherLiabilities', 'Other Liabilities')}
        
        {state.currentStep === 6 && (
          <div className="text-center py-8">
            <div className="w-20 h-20 bg-slate-50 text-[#0070e0] rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="iconify text-4xl" data-icon="solar:magic-stick-bold-duotone"></span>
            </div>
            <h3 className="text-xl font-bold text-[#002169] mb-2">Almost Done</h3>
            <p className="text-slate-500 text-sm">Review your data one last time before we generate your final bank-ready statement.</p>
          </div>
        )}
      </div>

      <div className="flex justify-between items-center">
        <button onClick={onBack} className="text-sm font-bold text-[#002169] hover:underline px-4">Back</button>
        <button onClick={onNext} className="bg-[#002169] text-white px-10 py-3 rounded-full font-bold hover:bg-[#001c5a] transition-all">
          {state.currentStep === PFS_STEPS.length - 1 ? 'Review Statement' : 'Continue'}
        </button>
      </div>
    </div>
  );
};

export default StepFlow;
