
import React, { useRef, useState } from 'react';
import { PFSData, FinancialItem } from '../types';
import PDFPreview from './PDFPreview';

interface SummaryProps {
  data: PFSData;
  isLocked: boolean;
  onExportRequested: () => void;
  onEdit: () => void;
  onReset: () => void;
}

const Summary: React.FC<SummaryProps> = ({ data, isLocked, onExportRequested, onEdit, onReset }) => {
  const [isExporting, setIsExporting] = useState(false);
  const pdfRef = useRef<HTMLDivElement>(null);
  const formatCurrency = (val: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  const calculateTotal = (items: FinancialItem[]) => items.reduce((acc, curr) => acc + (curr.value || 0), 0);
  const totalAssets = calculateTotal(data.cashAssets) + calculateTotal(data.investmentAssets) + calculateTotal(data.realEstateAssets);
  const totalLiabilities = calculateTotal(data.realEstateLiabilities) + calculateTotal(data.otherLiabilities);
  const netWorth = totalAssets - totalLiabilities;

  const handleExport = async () => {
    if (isLocked) { onExportRequested(); return; }
    if (!pdfRef.current) return;
    setIsExporting(true);
    try {
      // @ts-ignore
      const html2canvas = window.html2canvas;
      // @ts-ignore
      const { jsPDF } = window.jspdf;
      const canvas = await html2canvas(pdfRef.current, { scale: 2, useCORS: true, backgroundColor: '#ffffff' });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`PFS_${data.fullName.replace(/\s+/g, '_') || 'Fillio'}.pdf`);
    } catch (error) { console.error('Export failed', error); } finally { setIsExporting(false); }
  };

  return (
    <div className="min-h-full py-12 px-6 fade-in bg-[#F5F7FA]">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-12">
        <div className="lg:col-span-1 space-y-6">
          <h2 className="text-2xl font-bold text-[#002169]">Review Statement</h2>
          
          <div className="bg-white rounded-2xl p-6 shadow-xl shadow-slate-200/20 space-y-6">
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Total Assets</p>
                <p className="text-lg font-bold text-[#002169]">{formatCurrency(totalAssets)}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Liabilities</p>
                <p className="text-lg font-bold text-[#002169]">{formatCurrency(totalLiabilities)}</p>
              </div>
              <div className="pt-4 border-t border-slate-100">
                <p className="text-[10px] font-bold text-[#0070e0] uppercase tracking-widest mb-1">Net Worth</p>
                <p className="text-2xl font-bold text-[#002169]">{formatCurrency(netWorth)}</p>
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-50">
              <button
                onClick={handleExport}
                disabled={isExporting}
                className="w-full bg-[#0070e0] hover:bg-[#005ea6] text-white py-3 rounded-full font-bold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50"
              >
                <span className="iconify text-xl" data-icon={isLocked ? "solar:lock-bold-duotone" : "solar:printer-bold-duotone"}></span>
                {isLocked ? 'Unlock Download' : 'Export PDF'}
              </button>
              <button
                onClick={onEdit}
                className="w-full border-2 border-[#002169] text-[#002169] py-3 rounded-full font-bold text-sm transition-all hover:bg-slate-50"
              >
                Edit Data
              </button>
              <button onClick={onReset} className="w-full text-slate-400 font-bold text-[10px] uppercase tracking-widest hover:text-red-500">Reset</button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-3">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden relative">
            <div className={`p-8 bg-[#F5F7FA] overflow-auto flex justify-center ${isLocked ? 'filter blur-[2px]' : ''}`}>
              <div ref={pdfRef} className="origin-top scale-[0.7] transform-gpu">
                <PDFPreview data={data} totalAssets={totalAssets} totalLiabilities={totalLiabilities} netWorth={netWorth} />
              </div>
            </div>
            {isLocked && (
              <div className="absolute inset-0 flex items-center justify-center bg-white/40 backdrop-blur-sm">
                <div className="bg-white p-8 rounded-2xl shadow-2xl text-center max-w-sm">
                  <span className="iconify text-5xl text-[#0070e0] mb-4 mx-auto" data-icon="solar:document-add-bold-duotone"></span>
                  <h4 className="text-xl font-bold text-[#002169] mb-2">Statement Ready</h4>
                  <p className="text-slate-500 text-sm mb-6">Unlock to download your high-resolution, lender-ready financial PDF.</p>
                  <button onClick={onExportRequested} className="bg-[#002169] text-white px-8 py-3 rounded-full font-bold hover:bg-[#001c5a] transition-all">Unlock Now</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Summary;
