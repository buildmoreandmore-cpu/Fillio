
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  currentView: string;
  onHomeClick: () => void;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, currentView, onHomeClick, onLogout }) => {
  const recentDocs = [
    { id: '1', title: 'Personal Financial Statement', status: 'DRAFT', date: 'Edited 2 days ago', type: 'draft' },
    { id: '2', title: 'Debt Schedule 2024', status: 'COMPLETE', date: 'Dec 15, 2024', type: 'complete' },
    { id: '3', title: 'Q4 Balance Sheet', status: 'COMPLETE', date: 'Nov 28, 2024', type: 'complete' },
  ];

  return (
    <div className="flex h-screen bg-[#F8FAFC] overflow-hidden">
      {/* Primary Rail - Darker Background */}
      <aside className="w-[76px] flex-shrink-0 border-r border-slate-200 flex flex-col items-center py-8 justify-between bg-slate-100 z-30">
        <div className="flex flex-col items-center gap-10">
          <button 
            onClick={onHomeClick} 
            className="w-12 h-12 bg-[#002169] rounded-xl flex items-center justify-center text-white transition-all hover:scale-105 shadow-lg shadow-[#002169]/20"
          >
            <span className="iconify text-2xl" data-icon="solar:wallet-bold-duotone"></span>
          </button>
          
          <nav className="flex flex-col gap-8 text-slate-400">
            <button className="group relative p-2 hover:text-[#0070e0] transition-colors">
              <span className="iconify text-2xl" data-icon="solar:home-2-bold-duotone"></span>
              <span className="absolute left-14 bg-[#002169] text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap">Home</span>
            </button>
            <button className="group relative p-2 hover:text-[#0070e0] transition-colors">
              <span className="iconify text-2xl" data-icon="solar:history-bold-duotone"></span>
              <span className="absolute left-14 bg-[#002169] text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap">History</span>
            </button>
            <button className="group relative p-2 hover:text-[#0070e0] transition-colors">
              <span className="iconify text-2xl" data-icon="solar:settings-bold-duotone"></span>
              <span className="absolute left-14 bg-[#002169] text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap">Settings</span>
            </button>
          </nav>
        </div>
        <button className="p-2 text-slate-400 hover:text-[#0070e0] relative">
          <span className="iconify text-2xl" data-icon="solar:bell-bold-duotone"></span>
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-slate-100"></span>
        </button>
      </aside>

      {/* Workspace Sidebar - White Background */}
      <aside className="w-[320px] flex-shrink-0 border-r border-slate-200 bg-white flex flex-col z-20">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between">
          <span className="text-[11px] font-black text-[#002169] uppercase tracking-[0.15em]">Workspace</span>
          <span className="iconify text-slate-300" data-icon="solar:alt-arrow-down-linear"></span>
        </div>

        <div className="p-6 flex flex-col flex-grow overflow-y-auto scrollbar-hide">
          <button 
            onClick={onHomeClick}
            className="w-full bg-[#0070e0] hover:bg-[#005ea6] text-white py-3.5 rounded-xl flex items-center justify-center gap-2 text-sm font-bold transition-all shadow-lg shadow-[#0070e0]/20 active:scale-95 mb-10"
          >
            <span className="iconify text-xl" data-icon="solar:add-circle-bold-duotone"></span>
            New Document
          </button>

          {/* Recent Activity with Cards */}
          <div className="space-y-6">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.1em] px-1">Recent Activity</h4>
            <div className="space-y-3">
              {recentDocs.map((doc) => (
                <div 
                  key={doc.id} 
                  className="p-4 bg-white border border-slate-100 rounded-xl transition-all duration-300 cursor-pointer shadow-[0_1px_3px_rgba(0,0,0,0.08)] hover:shadow-[0_4px_12px_rgba(0,0,0,0.12)] hover:-translate-y-1 group"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-2 h-2 rounded-full ${doc.type === 'draft' ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
                    <span className={`text-[10px] font-black uppercase tracking-wider ${doc.type === 'draft' ? 'text-amber-600' : 'text-emerald-600'}`}>
                      {doc.status}
                    </span>
                  </div>
                  <h5 className="text-sm font-bold text-[#002169] mb-1 leading-tight group-hover:text-[#0070e0] transition-colors">{doc.title}</h5>
                  <p className="text-[10px] text-slate-400 font-semibold">{doc.date}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats Section */}
          <div className="mt-10 pt-8 border-t border-slate-50">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.1em] px-1 mb-4">Quick Stats</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-50 p-3 rounded-lg">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Documents</p>
                <p className="text-lg font-black text-[#002169]">12</p>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Storage</p>
                <p className="text-lg font-black text-[#002169]">84%</p>
              </div>
            </div>
          </div>
        </div>

        {/* User Profile - More Presence */}
        <div className="p-6 border-t border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <div className="w-14 h-14 bg-white border-2 border-slate-200 rounded-2xl flex items-center justify-center font-black text-lg text-[#002169] shadow-sm">JD</div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 border-2 border-white rounded-full"></div>
            </div>
            <div>
              <p className="text-base font-black text-[#002169] leading-none mb-1.5">John Doe</p>
              <div className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider">
                 <span className="iconify" data-icon="solar:medal-star-bold"></span>
                 Pro Member
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button className="flex-1 bg-white border border-slate-200 hover:bg-slate-50 text-[#002169] py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-colors">
              Settings
            </button>
            <button 
              onClick={onLogout}
              className="px-3 bg-white border border-slate-200 hover:bg-red-50 hover:text-red-600 text-slate-400 py-2 rounded-lg transition-all"
              title="Logout"
            >
              <span className="iconify text-lg" data-icon="solar:logout-2-linear"></span>
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-grow flex flex-col overflow-hidden bg-white">
        <header className="h-16 flex items-center justify-between px-10 bg-white border-b border-slate-100">
           <div className="flex items-center gap-2">
             <span className="text-xs font-black text-[#002169] uppercase tracking-[0.2em]">Dashboard</span>
           </div>
           <div className="flex items-center gap-4 text-slate-300">
             <span className="iconify text-xl" data-icon="solar:magnifer-linear"></span>
             <div className="h-4 w-[1px] bg-slate-100 mx-2"></div>
             <span className="iconify text-xl" data-icon="solar:question-square-linear"></span>
           </div>
        </header>
        <main className="flex-grow overflow-y-auto bg-white">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
