
import React from 'react';

interface AuthModalProps {
  mode: 'signin' | 'signup';
  onClose: () => void;
  onSuccess: () => void;
  setMode: (mode: 'signin' | 'signup') => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ mode, onClose, onSuccess, setMode }) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-[#002169]/30 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white rounded-[2rem] shadow-2xl p-10 fade-in">
        <button onClick={onClose} className="absolute top-8 right-8 text-slate-300 hover:text-[#002169] transition-colors">
          <span className="iconify text-2xl" data-icon="solar:close-circle-bold-duotone"></span>
        </button>
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-[#002169] mb-2">{mode === 'signin' ? 'Log In' : 'Sign Up'}</h2>
          <p className="text-slate-500 text-sm">Join Fillio for secure document management.</p>
        </div>
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); onSuccess(); }}>
          {mode === 'signup' && (
            <input 
              type="text" 
              placeholder="Full Name" 
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:border-[#0070e0] font-bold text-[#002169]"
              required 
            />
          )}
          <input 
            type="email" 
            placeholder="Email Address" 
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:border-[#0070e0] font-bold text-[#002169]"
            required 
          />
          <input 
            type="password" 
            placeholder="Password" 
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:border-[#0070e0] font-bold text-[#002169]"
            required 
          />
          <button type="submit" className="w-full bg-[#002169] text-white py-3 rounded-full text-sm font-bold mt-4 hover:bg-[#001c5a] transition-all">
            {mode === 'signin' ? 'Log In' : 'Create Account'}
          </button>
        </form>
        <div className="mt-8 text-center">
          <p className="text-xs font-bold text-slate-400">
            {mode === 'signin' ? "New to Fillio?" : "Already have an account?"}
            {' '}
            <button onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')} className="text-[#0070e0] hover:underline">
              {mode === 'signin' ? 'Sign Up' : 'Log In'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
