
import React from 'react';
import { PFSData } from '../types';
import PDFPreview from './PDFPreview';

interface PaywallProps {
  data: PFSData;
  onBack: () => void;
  onSuccess: (type: 'one-time' | 'subscription') => void;
  onSignup: () => void;
}

const Paywall: React.FC<PaywallProps> = ({ data, onBack, onSuccess, onSignup }) => {
  return (
    <div className="min-h-full py-20 px-6 flex flex-col items-center max-w-7xl mx-auto fade-in">
      <div className="text-center mb-16 max-w-2xl">
        <h2 className="text-5xl font-bold text-[#002169] mb-6 tracking-tight">Your document <span className="text-[#0070e0]">is ready 🎉</span></h2>
        <p className="text-slate-500 text-lg font-medium leading-relaxed">
          Download your bank-ready Personal Financial Statement. Join thousands of pros securing better deals.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 w-full items-start">
        <div className="relative group">
          <div className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-100 max-h-[700px]">
            <div className="p-8 origin-top scale-[0.8] transform-gpu filter blur-[4px] opacity-40 grayscale">
              <PDFPreview data={data} totalAssets={1250000} totalLiabilities={450000} netWorth={800000} />
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div 
            onClick={() => onSuccess('one-time')}
            className="group relative bg-white border-2 border-slate-100 hover:border-[#0070e0] rounded-[1.5rem] p-8 cursor-pointer transition-all hover:shadow-xl"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-bold text-[#002169] mb-1">One-time download</h3>
                <p className="text-slate-500 text-sm">Download this document only.</p>
              </div>
              <div className="text-3xl font-bold text-[#002169]">$9</div>
            </div>
            <button className="w-full bg-slate-50 text-[#002169] group-hover:bg-[#002169] group-hover:text-white py-3 rounded-full text-sm font-bold transition-all">
              Choose Single Download
            </button>
          </div>

          <div 
            onClick={() => onSuccess('subscription')}
            className="group relative bg-white border-2 border-[#002169] ring-8 ring-[#002169]/5 rounded-[1.5rem] p-8 cursor-pointer transition-all hover:shadow-2xl"
          >
            <div className="absolute -top-3 right-6 bg-[#0070e0] text-white text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full">Best Value</div>
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-bold text-[#002169] mb-1">Unlimited Pro</h3>
                <p className="text-slate-500 text-sm">Unlimited docs + all features.</p>
              </div>
              <div className="text-3xl font-bold text-[#002169]">$12<span className="text-sm text-slate-400">/mo</span></div>
            </div>
            <button className="w-full bg-[#002169] text-white py-3 rounded-full text-sm font-bold transition-all hover:bg-[#001c5a]">
              Get Unlimited Pro
            </button>
          </div>

          <div className="pt-8 text-center">
             <button onClick={onBack} className="text-slate-400 hover:text-[#002169] font-bold text-xs uppercase tracking-widest">Back to review</button>
          </div>
        </div>
      </div>

      <div className="mt-20 p-8 bg-[#F5F7FA] rounded-[2rem] border border-slate-200 flex flex-col md:flex-row items-center gap-8 max-w-4xl w-full">
         <div className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-[#0070e0]">
            <span className="iconify text-2xl" data-icon="solar:shield-keyhole-bold-duotone"></span>
         </div>
         <div className="flex-grow">
            <h4 className="text-base font-bold text-[#002169] mb-1">Want to save your work?</h4>
            <p className="text-slate-500 text-sm">Create a free account to save this document as a draft.</p>
         </div>
         <button onClick={onSignup} className="bg-white border-2 border-[#002169] text-[#002169] px-8 py-3 rounded-full text-xs font-bold hover:bg-slate-50 transition-all">Create Account</button>
      </div>
    </div>
  );
};

export default Paywall;
