
import React from 'react';
import { DOC_OPTIONS } from '../constants';
import { DocumentType } from '../types';

interface LandingPageProps {
  onGetStarted: () => void;
  onSignIn: () => void;
  onDocClick: (type: DocumentType) => void;
}

const DocumentPreviewSkeleton: React.FC<{ type: DocumentType }> = ({ type }) => {
  switch (type) {
    case DocumentType.PFS:
      return (
        <div className="flex gap-2 w-full h-full p-3 bg-white">
          <div className="flex-1 flex flex-col gap-2">
            <div className="h-2 w-4/5 bg-blue-100 rounded-sm"></div>
            <div className="h-1.5 w-full bg-slate-100 rounded-sm"></div>
            <div className="h-1.5 w-full bg-slate-100 rounded-sm"></div>
            <div className="h-1.5 w-full bg-slate-100 rounded-sm"></div>
          </div>
          <div className="flex-1 flex flex-col gap-2">
            <div className="h-2 w-4/5 bg-indigo-100 rounded-sm"></div>
            <div className="h-1.5 w-full bg-slate-50 rounded-sm"></div>
            <div className="h-1.5 w-full bg-slate-50 rounded-sm"></div>
          </div>
        </div>
      );
    case DocumentType.DEBT_SCHEDULE:
      return (
        <div className="w-full h-full p-3 flex flex-col gap-2.5 bg-white">
          <div className="h-2 w-1/2 bg-slate-200 rounded-sm mb-1"></div>
          {[...Array(4)].map((_, i) => (
            <div key={i} className="flex gap-1.5 items-center border-b border-slate-50 pb-1.5">
              <div className="w-8 h-1.5 bg-slate-200 rounded-sm"></div>
              <div className="flex-1 h-1.5 bg-slate-100 rounded-sm"></div>
              <div className="w-6 h-1.5 bg-blue-200 rounded-sm"></div>
            </div>
          ))}
        </div>
      );
    case DocumentType.INCOME_STATEMENT:
      return (
        <div className="w-full h-full p-3 flex flex-col bg-white">
          <div className="h-2 w-1/3 bg-slate-200 rounded-sm mb-3"></div>
          <div className="h-4 w-full bg-blue-50 rounded-sm mb-2"></div>
          <div className="flex flex-col gap-1.5 mb-4">
            <div className="h-1 w-full bg-slate-100 rounded-sm"></div>
            <div className="h-1 w-full bg-slate-100 rounded-sm"></div>
            <div className="h-1 w-full bg-slate-100 rounded-sm"></div>
          </div>
          <div className="mt-auto h-3 w-3/4 bg-blue-600/20 rounded-sm self-center"></div>
        </div>
      );
    case DocumentType.BALANCE_SHEET:
      return (
        <div className="w-full h-full p-3 flex flex-col gap-2 bg-white">
          <div className="flex-[1.2] bg-slate-50 border border-slate-100 rounded-sm flex flex-col p-1.5 gap-1.5">
            <div className="h-1.5 w-1/2 bg-blue-100 rounded-sm"></div>
            <div className="h-1 w-full bg-slate-200/50 rounded-sm"></div>
          </div>
          <div className="flex-1 bg-slate-50 border border-slate-100 rounded-sm flex flex-col p-1.5 gap-1.5">
            <div className="h-1.5 w-1/2 bg-indigo-100 rounded-sm"></div>
            <div className="h-1 w-full bg-slate-200/50 rounded-sm"></div>
          </div>
          <div className="flex-1 bg-blue-50 border border-blue-100/50 rounded-sm flex flex-col p-1.5 gap-1.5">
            <div className="h-1.5 w-1/2 bg-blue-200 rounded-sm"></div>
          </div>
        </div>
      );
    default:
      return <div className="w-full h-full bg-slate-50 flex items-center justify-center text-slate-300">DOC</div>;
  }
};

const ShowcaseCard: React.FC<{ doc: any; onSelect: (type: DocumentType) => void }> = ({ doc, onSelect }) => {
  return (
    <div 
      className="group flex flex-col bg-white border border-slate-100 rounded-[1.5rem] p-6 transition-all duration-300 hover:shadow-[0_20px_40px_-10px_rgba(0,0,0,0.1)] cursor-pointer h-full"
      onClick={() => onSelect(doc.type)}
    >
      <div className="relative h-48 bg-[#F5F7FA] rounded-xl mb-6 overflow-hidden flex items-center justify-center">
        {/* Decorative background elements */}
        <div className="absolute top-2 left-4 w-12 h-12 rounded-full bg-slate-200 opacity-50"></div>
        <div className="absolute bottom-2 right-6 w-16 h-16 rounded-full bg-blue-600/5"></div>
        
        {/* Stylized Document Preview */}
        <div className="relative z-10 w-28 h-36 bg-white rounded-lg shadow-xl border border-slate-200/50 overflow-hidden transform transition-all group-hover:scale-105 group-hover:-translate-y-1 duration-500">
           <DocumentPreviewSkeleton type={doc.type} />
        </div>
      </div>

      <div className="flex flex-col flex-grow text-center">
        <h3 className="text-xl font-bold text-[#002169] mb-3">{doc.title}</h3>
        <p className="text-slate-500 text-sm leading-relaxed mb-6 flex-grow">
          {doc.outcomeDescription}
        </p>

        <div className="mt-auto">
           <button 
             className="w-full bg-[#002169] text-white py-3 rounded-full text-sm font-bold transition-all hover:bg-[#001c5a]"
           >
             Start Building
           </button>
        </div>
      </div>
    </div>
  );
};

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, onSignIn, onDocClick }) => {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="h-20 flex items-center justify-between px-6 md:px-12 max-w-7xl mx-auto">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2">
            <span className="iconify text-3xl text-[#002169]" data-icon="solar:wallet-bold-duotone"></span>
            <span className="text-2xl font-bold text-[#002169] tracking-tighter">Fillio</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button onClick={onSignIn} className="border-2 border-[#002169] text-[#002169] px-6 py-2 rounded-full text-sm font-bold hover:bg-slate-50 transition-all">Log In</button>
          <button 
            onClick={onGetStarted}
            className="bg-[#002169] text-white px-6 py-2 rounded-full text-sm font-bold hover:bg-[#001c5a] transition-all"
          >
            Sign Up
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-12 pb-24 px-6 text-center max-w-5xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold text-[#002169] mb-8 leading-[1.1] tracking-tight">
          Professional financial <br/><span className="text-[#0070e0]">documents in minutes.</span>
        </h1>
        <p className="text-slate-500 text-lg md:text-xl font-medium mb-10 max-w-2xl mx-auto">
          Skip the spreadsheets. Use our guided multi-step flow to create lender-ready PDFs. No signup required to start.
        </p>
        <button 
          onClick={() => document.getElementById('templates')?.scrollIntoView({ behavior: 'smooth' })}
          className="bg-[#002169] hover:bg-[#001c5a] text-white px-10 py-4 rounded-full text-base font-bold transition-all active:scale-95 shadow-lg shadow-[#002169]/20"
        >
          Start Your First Doc →
        </button>
      </section>

      {/* Document Showcase - Partner Directory Style */}
      <section id="templates" className="py-24 bg-[#F5F7FA]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#002169] tracking-tight">
              Bank-Ready <span className="text-[#0070e0]">Templates</span>
            </h2>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {DOC_OPTIONS.map((doc) => (
              <ShowcaseCard 
                key={doc.type} 
                doc={doc} 
                onSelect={onDocClick} 
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Footer copyright */}
      <footer className="py-12 px-6 border-t border-slate-100 text-center">
         <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">© 2024 Fillio. Professional. Always.</p>
      </footer>
    </div>
  );
};

export default LandingPage;
